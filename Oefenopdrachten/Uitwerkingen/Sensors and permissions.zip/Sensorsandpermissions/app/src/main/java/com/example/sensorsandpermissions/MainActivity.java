package com.example.sensorsandpermissions;

import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;


import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    Button buttonCamera;
    Button buttonVibrate;
    Button buttonApi;
    Button buttonCounter;

    ImageView imageCameraPreview;
    ImageView imageApiResult;

    TextView textCounter;

    int counter = 0;

    SharedPreferences preferences;

    // Camera result handler
    ActivityResultLauncher<Intent> cameraLauncher;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Verbinden van elementen met code
        buttonCamera = findViewById(R.id.buttonCamera);
        buttonVibrate = findViewById(R.id.buttonVibrate);
        buttonApi = findViewById(R.id.buttonApi);
        buttonCounter = findViewById(R.id.buttonCounter);

        imageCameraPreview = findViewById(R.id.imageCameraPreview);
        imageApiResult = findViewById(R.id.imageApiResult);

        textCounter = findViewById(R.id.textCounter);

        // SharedPreferences setup
        preferences = getSharedPreferences("appdata", MODE_PRIVATE);

        counter = preferences.getInt("counter", 0);
        textCounter.setText("Counter: " + counter);

        // Camera result launcher
        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == RESULT_OK) {

                        Bundle extras = result.getData().getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");

                        imageCameraPreview.setImageBitmap(imageBitmap);
                    }
                });

        // CAMERA BUTTON
        buttonCamera.setOnClickListener(v -> openCamera());



        // VIBRATIE BUTTON
        buttonVibrate.setOnClickListener(v -> vibratePhone());

        // API BUTTON
        buttonApi.setOnClickListener(v -> fetchCatApi());


        // COUNTER BUTTON
        buttonCounter.setOnClickListener(v -> increaseCounter());

    }

    private void openCamera(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    100);

            return;
        }

        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraLauncher.launch(cameraIntent);
    }

    private void vibratePhone() {

        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));

        } else {

            vibrator.vibrate(500);
        }
    }

    private void fetchCatApi() {

        new Thread(() -> {

            try {

                URL url = new URL("https://api.thecatapi.com/v1/images/search");

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream()));

                StringBuilder response = new StringBuilder();

                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();

                JSONArray jsonArray = new JSONArray(response.toString());

                JSONObject catObject = jsonArray.getJSONObject(0);
                String imageUrl = catObject.getString("url");

                runOnUiThread(() -> {

                    Glide.with(MainActivity.this)
                            .load(imageUrl)
                            .into(imageApiResult);

                });

            } catch (Exception e) {

                e.printStackTrace();
            }

        }).start();
    }

    private void increaseCounter() {

        counter++;
        textCounter.setText("Counter: " + counter);

        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("counter", counter);
        editor.apply();
    }


}