package com.example.fragmentsandlayering;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.helper.widget.Layer;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainer;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    public String keyA = "123";
    public String keyB = "456";
    public String keyC = "789";
    public String keyD = "QWERTY";
    public String keyE = "WASD";

    public static final String LAYER_TAG = "LayerFragment";
    public FragmentManager fragmentManager;

    public FragmentContainerView MainContainer;

    //Indien nodig kan je dit gebruiken
    //public LayerFragment LayerFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        fragmentManager = getSupportFragmentManager();
        //TODO: Koppel de gemaakte container
        MainContainer = findViewById(R.id.MainContainer);

        FloatingActionButton FirstFragmentButton = findViewById(R.id.FirstFragmentButton);
        FirstFragmentButton.setOnClickListener(View ->{
            FirstFragment newFragment = new FirstFragment(this);
            //TODO: maak een nieuwe FirstFragment aan

            fragmentManager.beginTransaction()
                    .replace(R.id.MainContainer, newFragment, null)
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .commit();
            //TODO: plaats de FirstFragment in de MainContainer


        });

        FloatingActionButton SecondFragmentButton = findViewById(R.id.SecondFragmentButton);
        SecondFragmentButton.setOnClickListener(View ->{
            SecondFragment newFragment = new SecondFragment(this);

            //TODO: maak een nieuwe SecondFragment aan
            fragmentManager.beginTransaction().replace(R.id.MainContainer, newFragment, null).commit();
            //TODO: plaats de SecondFragment in de MainContainer

        });

        FloatingActionButton AddLayerButton = findViewById(R.id.AddLayerFragmentButton);
        AddLayerButton.setOnClickListener(View ->{
            Fragment existingLayer = fragmentManager.findFragmentByTag(LAYER_TAG);
            //TODO: Maak een nieuwe LayerFragment aan
            if(existingLayer == null){
                LayerFragment newFragment = new LayerFragment(this);
                fragmentManager.beginTransaction().add(R.id.MainContainer, newFragment,LAYER_TAG).commit();
            }
            //TODO: voeg deze toe aan de MainContainer


        });

        FloatingActionButton RemoveLayerButton = findViewById(R.id.RemoveLayerFragmentButton);
        RemoveLayerButton.setOnClickListener(View ->{
            //TODO: verwijder de LayerFragment uit de MainContainer zonder deze leeg te maken.
            Fragment existingLayer = fragmentManager.findFragmentByTag(LAYER_TAG);
               if(existingLayer != null){
                    fragmentManager.beginTransaction().remove(existingLayer).commit();
               }


        });




    }
}


/*
    TODO: Maak en koppel de fragmentcontainer
    TODO: Maak 3 fragments aan: FirstFragment, SecondFragment en LayerFragment
    Zorg ervoor dat je  de layer fragment geen sollide achtergrond kleur geeft
    Om een nieuwe fragment te maken: rechter muis knop op res folder -> new -> Fragment -> Fragment (Blank)
    TODO: geef bij deze fragments of de mainActivity of variabelen mee in de constructor
    Zorg ervoor dat je onderscheid kan maken tussen de 3 fragments
 */