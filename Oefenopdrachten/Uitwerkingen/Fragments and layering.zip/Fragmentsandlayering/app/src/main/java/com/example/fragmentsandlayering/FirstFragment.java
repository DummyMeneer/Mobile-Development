package com.example.fragmentsandlayering;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class FirstFragment extends Fragment {

    private MainActivity mainActivity;
    public String displayText = "Default";

    public FirstFragment(MainActivity main) {
        this.mainActivity = main;
        displayText = mainActivity.keyA + mainActivity.keyB;
    }

    public FirstFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView keyText = view.findViewById(R.id.FirstKeyText);
        keyText.setText(displayText);
    }
}