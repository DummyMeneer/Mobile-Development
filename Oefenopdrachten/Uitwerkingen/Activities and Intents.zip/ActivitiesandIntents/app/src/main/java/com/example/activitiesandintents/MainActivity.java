package com.example.activitiesandintents;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    public String key = "12345567 and 8";
    public String keyB = "What about 9 and 10";

    public String keyC = "Numbers arent necessary for coding";
    public String keyD = "Yes you do";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button NextPageButton = findViewById(R.id.button);
        TextView textView = findViewById(R.id.mainKeyText);

        NextPageButton.setOnClickListener(view -> {
            //TODO: maak hier een intent aan
            Intent switchActivity = new Intent(this, SecondActivity.class);
            switchActivity.putExtra("key", keyB);
            this.startActivity(switchActivity);
        });



    }
}

/*
TODO list:
- maak een tweede activity aan (rechtermuisknop op res folder ->
                            new -> activity -> empty views activity )
- Maak een textView aan in de tweede activity
- Maak een intent aan binnen de NextPageButton on click listener
- Geef de intent een variabel mee
- Gebruik die variabel in de tweede pagina
- Test je applicatie
 */




