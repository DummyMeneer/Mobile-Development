package com.example.fragmentsandlayering;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainer;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    public String keyA = "123";
    public String keyB = "456";
    public String keyC = "789";
    public String keyD = "QWERTY";
    public String keyE = "WASD";

    public FragmentContainer MainContainer;

    //Indien nodig kan je dit gebruiken
    //public LayerFragment LayerFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //TODO: Koppel de gemaakte container

        FloatingActionButton FirstFragmentButton = findViewById(R.id.FirstFragmentButton);
        FirstFragmentButton.setOnClickListener(View ->{
            //TODO: maak de container leeg

            //TODO: maak een nieuwe FirstFragment aan

            //TODO: plaats de FirstFragment in de MainContainer


        });

        FloatingActionButton SecondFragmentButton = findViewById(R.id.FirstFragmentButton);
        SecondFragmentButton.setOnClickListener(View ->{
            //TODO: maak de container leeg

            //TODO: maak een nieuwe SecondFragment aan

            //TODO: plaats de SecondFragment in de MainContainer

        });

        FloatingActionButton AddLayerButton = findViewById(R.id.FirstFragmentButton);
        AddLayerButton.setOnClickListener(View ->{
            //TODO: Maak een nieuwe LayerFragment aan

            //TODO: voeg deze toe aan de MainContainer


        });

        FloatingActionButton RemoveLayerButton = findViewById(R.id.FirstFragmentButton);
        RemoveLayerButton.setOnClickListener(View ->{
            //TODO: verwijder de LayerFragment uit de MainContainer zonder deze leeg te maken.


        });




    }
}


/*
    TODO: Maak en koppel de fragmentcontainer
    TODO: Maak 3 fragments aan: FirstFragment, SecondFragment en LayerFragment
    Zorg ervoor dat je  de layer fragment geen sollide achtergrond kleur geeft
    Om een nieuwe fragment te maken: rechter muis knop op res folder -> new -> Fragment -> Fragment (Blank)
    TODO: geef bij deze fragments of de mainActivity of variabelen mee in de constructor
    Zorg ervoor dat je onderscheid kan maken tussen de 3 fragments
 */