package com.example.sensorsandpermissions;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class MainActivity extends AppCompatActivity {

    Button buttonCamera;
    Button buttonVibrate;
    Button buttonApi;
    Button buttonCounter;

    ImageView imageCameraPreview;
    ImageView imageApiResult;

    TextView textCounter;

    int counter = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Verbinden van elementen met code
        buttonCamera = findViewById(R.id.buttonCamera);
        buttonVibrate = findViewById(R.id.buttonVibrate);
        buttonApi = findViewById(R.id.buttonApi);
        buttonCounter = findViewById(R.id.buttonCounter);

        imageCameraPreview = findViewById(R.id.imageCameraPreview);
        imageApiResult = findViewById(R.id.imageApiResult);

        textCounter = findViewById(R.id.textCounter);

        /*
        ========================================
        Opdracht instructies INSTRUCTIONS
        ========================================

        De xml is alvast voorbereid voor jullie net als het koppelen van de elementen
        Jullie taak is om voor iedere knop de code te onderzoeken en implementeren op basis van
        de hints die zijn gegeven.
        Als iets niet werkt of je app is gecrasht, vergeet niet dat sommige functies een permission vereisen
        Die staan normaal in je android manifest, check dit!

        Functionaliteiten om te maken:
        1. Camera gebruik
        2. Phone vibratie
        3. API requests
        4. Locale opslag met sharedpreferences

        Lees de TODO's en implementeer de functionaliteiten
        voor een extra uitdaging: breid de app uit met een knop om Audio op te nemen en af te spelen

        ========================================
        */

        // CAMERA BUTTON
        buttonCamera.setOnClickListener(v -> openCamera());

        // VIBRATIE BUTTON
        buttonVibrate.setOnClickListener(v -> vibratePhone());

        // API BUTTON
        buttonApi.setOnClickListener(v -> fetchCatApi());

        // COUNTER BUTTON
        buttonCounter.setOnClickListener(v -> increaseCounter());

    }

    private void openCamera(){
                /*
                TODO: CAMERA IMPLEMENTATION
                1. Voeg de camera permssion toe aan het AndroidManifest.xml
                   <uses-permission android:name="android.permission.CAMERA"/>

                2. Maak een intent naar:
                   MediaStore.ACTION_IMAGE_CAPTURE

                3. Start de camera activity met startActivityForResult()

                4. Override onActivityResult() om de afbeelding te ontvangen

                5. converteer het resultaat naar een Bitmap en weergeef deze in de image
                   imageCameraPreview.setImageBitmap(bitmap);

                Hint: Voor de camera moet je nog een ActivityResultLauncher maken in de onCreate(). Ik zou aanraden om deze globaal maken binnen mainActivity
                */
    }

    private void vibratePhone() {
                /*
                TODO: VIBRATION IMPLEMENTATION
                1. Voeg permission toe aan AndroidManifest.xml:
                   <uses-permission android:name="android.permission.VIBRATE"/>

                2. Gebruik de Vibrator service:
                   Vibrator vibrator =
                   (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

                3. Activeer de vibratie voor 500 milliseconde.

                Hint:
                Moderne Android versies hebben VibrationEffect nodig.
                */


    }


    private void fetchCatApi() {
                /*
                TODO: API IMPLEMENTATION
                Suggested API:
                https://api.thecatapi.com/v1/images/search

                Voorbeeld reactie:
                [
                  {
                    "url": "https://cdn2.thecatapi.com/images/abc.jpg"
                  }
                ]

                1. Voeg INTERNET permission toe aan AndroidManifest.xml:
                   <uses-permission android:name="android.permission.INTERNET"/>

                2. Maak een netwerk verzoek aan (HttpURLConnection or OkHttp)
                3. Parse the JSON response
                4. Update imageApiResult

                Hint:
                Maak gebruik van libraries zoals Picasso of Glide om
                afbeeldingen makkelijker in te laden van een url
                */

    }




    private void increaseCounter() {
                /*
                TODO: PERSISTENT COUNTER
                1. Maak de counter variabele grooter met 1 iedere keer
                dat op de knop gedrukt wordt
                2. Weergeef de nieuwe counter in textCounter
                3. Roep de lokale opslag aan via shared preferences
                Voorbeeld stukje:
                SharedPreferences prefs = getSharedPreferences("appdata", MODE_PRIVATE);

                4. Save de waarde op

                5. Vergeet niet de waarde in te laden als deze in sharedpreferences bestaat


                Hint: Maak je shared preferences een globaal object zodat je overal in de main activity erbij kan.
                Deze wil je namelijk initializeren in de onCreate voordat je ermee gaat werken hier.
                */

    }


}